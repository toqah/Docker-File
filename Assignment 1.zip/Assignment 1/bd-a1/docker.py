import pandas as pd
import numpy as np

def preprocess_titanic_data(input_file, output_file):
    # Load the dataset
    df = pd.read_csv(input_file)

    # Feature Engineering
    df['FamilySize'] = df['SibSp'] + df['Parch']
    df["Title"] = df["Name"].str.extract(r', (Mr|Miss|Mrs)\.')

    # Data Cleaning
    def impute_missing_age(df):
        mean_age = df['Age'].mean()
        std_age = df['Age'].std()
        null_count = df['Age'].isnull().sum()
        missing_ages = np.random.normal(mean_age, std_age, null_count)
        missing_ages = np.clip(missing_ages, 0, df['Age'].max())
        df.loc[df['Age'].isnull(), 'Age'] = missing_ages

    def impute_missing_title(df):
        title_counts = df['Title'].value_counts()
        distribution = title_counts / title_counts.sum()
        null_count = df['Title'].isnull().sum()
        missing_titles = np.random.choice(distribution.index, null_count, p=distribution)
        df.loc[df['Title'].isnull(), 'Title'] = missing_titles

    def impute_missing_survived(df):
        survived_counts = df['Survived'].value_counts()
        distribution = survived_counts / survived_counts.sum()
        null_count = df['Survived'].isnull().sum()
        missing_survived = np.random.choice(distribution.index, null_count, p=distribution)
        df.loc[df['Survived'].isnull(), 'Survived'] = missing_survived

    impute_missing_age(df)
    impute_missing_title(df)
    impute_missing_survived(df)

    # Data Reduction
    df.drop(['PassengerId', 'Name'], axis=1, inplace=True)

    # Data Discretization
    age_bins = [0, 10, 20, 30, 40, 50, 60, 100]
    age_labels = ['0-10 years', '11-20 years', '21-30 years', '31-40 years', '41-50 years', '51-60 years', '61+ years']
    df['AgeGroup'] = pd.cut(df['Age'], bins=age_bins, labels=age_labels)

    fare_bins = [0, 20, 40, 60, 80, 100, 1000]
    fare_labels = ['0-20', '21-40', '41-60', '61-80', '81-100', '100+']
    df['Fare'].fillna(df['Fare'].mean(), inplace=True)
    df['FareGroup'] = pd.cut(df['Fare'], bins=fare_bins, labels=fare_labels)

    df['Embarked'] = df['Embarked'].fillna(df['Embarked'].mode()[0])
    df['IntAgeGroup'] = df['AgeGroup'].astype('category').cat.codes
    df['IntFareGroup'] = df['FareGroup'].astype('category').cat.codes
    df['IntTitle'] = df['Title'].astype('category').cat.codes
    df['IntSex'] = df['Sex'].astype('category').cat.codes
    df['IntEmbarked'] = df['Embarked'].astype('category').cat.codes
    df['IntTicket'] = df['Ticket'].astype('category').cat.codes
    df.drop(['AgeGroup', 'FareGroup', 'Title', 'Sex', 'Embarked', 'Cabin', 'Ticket'], axis=1, inplace=True)

    # Save the preprocessed data to a new file
    df.to_csv(output_file, index=False)

    return df

if __name__ == "__main__":
    input_file = "titanic.csv"
    output_file = "titanic_preprocessed.csv"
    preprocess_titanic_data(input_file, output_file)
