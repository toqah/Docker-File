import numpy as np

def calculate_cosine_similarity(df):
    def cosine_similarity(a, b):
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

    columns = df.columns
    results = np.zeros((len(columns), len(columns))

    for i in range(len(columns)):
        for j in range(len(columns)):
            col1 = df[columns[i]]
            col2 = df[columns[j]]
            similarity = cosine_similarity(col1, col2)
            results[i, j] = similarity

    return columns, results

def write_similarity_results_to_file(columns, results, output_file):
    with open(output_file, 'w') as f:
        for i in range(len(columns)):
            for j in range(len(columns)):
                f.write(f'Cosine similarity between {columns[i]} and {columns[j]}: {results[i, j]}\n')

if __name__ == "__main__":
    # Load your DataFrame (df) here

    columns, results = calculate_cosine_similarity(df)
    output_file = 'eda_similarity_results.txt'
    write_similarity_results_to_file(columns, results, output_file)
