import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, DBSCAN
from mpl_toolkits.mplot3d import Axes3D

def cluster_and_visualize(df, clustering_model, show_plot=True):
    # Perform dimensionality reduction with PCA
    pca = PCA(n_components=3)
    pca.fit(df.values)
    x_pca = pd.DataFrame(pca.transform(df.values), columns=["col1", "col2", "col3"])

    # Apply the selected clustering model
    if clustering_model == "KMeans":
        model = KMeans(n_clusters=3)
    elif clustering_model == "DBSCAN":
        model = DBSCAN(eps=0.5, min_samples=5)
    else:
        raise ValueError("Invalid clustering model")

    pre_clusters = model.fit_predict(x_pca)
    x_pca["Clusters"] = pre_clusters
    df["Clusters"] = pre_clusters

    # Count the number of records in each cluster
    cluster_counts = df['Clusters'].value_counts()

    # Define the file name
    file_name = f"{clustering_model.lower()}_results.txt"

    # Save the counts to the text file
    with open(file_name, "w") as file:
        for cluster, count in cluster_counts.items():
            file.write(f"Cluster {cluster}: {count} records\n")

    if show_plot:
        fig = plt.figure(figsize=(20, 15))
        plot = fig.add_subplot(111, projection='3d')
        plot.set_title(f"The Plot of {clustering_model} Clustering", fontsize=30)
        plot.scatter(x_pca['col1'], x_pca['col2'], x_pca['col3'], s=150, c=pre_clusters, marker='o', cmap='viridis', zorder=10)
        plt.show()

if __name__ == "__main__":
    data = pd.read_csv("titanic.csv")  

    cluster_and_visualize(data, "KMeans")
    cluster_and_visualize(data, "DBSCAN")
