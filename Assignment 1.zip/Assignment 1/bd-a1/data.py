import argparse
import pandas as pd

from data_loading import load_dataset
from data_visualization import visualize_data
from data_preprocessing import preprocess_data
from model import train_model
from exploratory_data_analysis import perform_eda

file_path = "titanic.csv"
loaded_data = load_dataset(file_path)

if loaded_data is not None:
    print("Dataset loaded successfully.")
else:
    print("Failed to load the dataset.")

def main():
    parser = argparse.ArgumentParser(description="Load a dataset from a specified file path and perform various tasks.")
    parser.add_argument("file_path", help="Path to the dataset file")

    args = parser.parse_args()
    file_path = args.file_path

    dataset = load_dataset(file_path)
    if dataset is not None:
        print("Dataset loaded successfully.")

        # Data visualization
        visualize_data(dataset)

        # Data preprocessing
        dataset = preprocess_data(dataset)

        # Model training
        train_model(dataset, True)

        # Exploratory Data Analysis
        perform_eda(dataset)

if __name__ == "__main__":
    main()
